/*
	shmcpy.h	WJ103
*/

void shmcpy_to(void *, char *, int);
char *shmcpy_from(void *, int);

/* EOB */
