/*
	mkmsgbuf.h	WJ103
*/

#include "ipc.h"

struct msgbuf *mkmsgbuf(int, char *);

/* EOB */
