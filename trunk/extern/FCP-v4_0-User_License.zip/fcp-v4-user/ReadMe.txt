================================
Flash Charts Pro v4.0

(C) Web-Site-Scripts.com
================================

PACKAGE CONTENT

1. "demo" folder - chart gallery with demo SWF and XML files
2. "fcp" folder - commercial SWF files with XML templates without visible copyright notice
3. "manual" folder - Flash Charts Pro HTML manual. You can view it using your internet browser. Please open index.html from your browser to view it.